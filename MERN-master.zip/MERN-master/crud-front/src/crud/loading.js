import React from 'react'
import {Spin, Sapce} from "antd";

const Loading=()=>(
    <Sapce size="middle">
        <Spin size="large"/> 
    </Sapce>
);

export default Loading; 